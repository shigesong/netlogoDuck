## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", message = FALSE)

## -----------------------------------------------------------------------------
library(netlogoDuck)

## -----------------------------------------------------------------------------
# A minimal BehaviorSpace-style export: two metadata lines, then the header.
csv_path <- file.path(tempdir(), "behavior-space.csv")
writeLines(
  c(
    '"BehaviorSpace results (NetLogo 7.0.4)"',
    '"/home/user/models/demo.nlogox"',
    '"[run number]","[step]","seed","density","final-wealth"',
    '"1","0","1","0.2","95"',
    '"2","0","2","0.5","140"',
    '"3","0","3","0.8","61"',
    '"4","0","4","0.5","132"'
  ),
  csv_path
)

db_path <- file.path(tempdir(), "demo.duckdb")
csv_to_duckdb(csv_path, db_path, table = "results", quiet = TRUE)

df <- read_results(db_path)
class(df)
df

## -----------------------------------------------------------------------------
df |>
  dplyr::filter(density > 0.3) |>
  dplyr::summarise(n = dplyr::n(), mean_wealth = mean(`final-wealth`))

## -----------------------------------------------------------------------------
local <- read_results(db_path, collect = TRUE)
class(local)

## -----------------------------------------------------------------------------
con <- db_open(db_path, read_only = TRUE)
DBI::dbGetQuery(
  con,
  'SELECT "density", COUNT(*) AS n FROM "results" GROUP BY 1 ORDER BY 1'
)
db_close(con)

