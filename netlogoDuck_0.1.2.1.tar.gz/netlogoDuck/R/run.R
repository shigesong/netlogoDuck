#' Run a NetLogo experiment and append its results to DuckDB
#'
#' Runs an experiment defined with [define_experiment()] through
#' [logolink::run_experiment()] and appends the tidy results table to a
#' DuckDB database. Each call stamps a unique `run_id` and experiment
#' metadata columns on every row so repeated runs can be filtered later.
#'
#' @param experiment A `netlogo_experiment` object from [define_experiment()].
#' @param db_path Path to the `.duckdb` database file. Created if missing.
#' @param table Name of the results table in the database.
#' @param threads Number of threads passed to the NetLogo headless runner
#'   (via `other_arguments = "--threads N"`). Set to `NULL` to omit the flag and
#'   control threading through `other_arguments` instead.
#' @param timeout Maximum time in seconds to wait for NetLogo (see
#'   [logolink::run_experiment()]).
#' @param metadata Optional named list of extra values stamped on every row
#'   (e.g. `list(design = "H6")`).
#' @param smoke Logical; if `TRUE`, forces 1 repetition and 5 ticks for a
#'   quick validation run without editing the experiment object.
#' @param output Additional logolink output types, appended to `"table"`
#'   (e.g. `"lists"` for NetLogo list metrics).
#' @param tidy_output Passed to [logolink::run_experiment()].
#' @param db_con Optional: an existing connection from [db_open()]. If given,
#'   `db_path` is ignored and the connection is left open on exit.
#' @param quiet_fail Logical; if `TRUE`, convert a failed NetLogo run into a
#'   warning and return zero rows. Defaults to `FALSE`, so execution failures
#'   are errors and cannot be mistaken for successful empty results.
#' @param experiment_name Optional name of an experiment stored in the NetLogo
#'   model file. When supplied, [logolink::run_experiment()] runs that experiment
#'   instead of the generated setup file, so `smoke` cannot be combined with it.
#'   The `repetitions` and `time_limit` columns are then `NA`, because the
#'   model-file experiment defines its own run length.
#' @param other_arguments Optional character vector of extra command-line
#'   arguments for the NetLogo executable (see [logolink::run_experiment()]).
#'   `"--threads N"` is prepended when `threads` is not `NULL`.
#' @param output_dir Directory where NetLogo writes its output files. Passed to
#'   [logolink::run_experiment()] and must already exist.
#'
#' @return Invisibly, the number of rows appended to the database.
#' @export
#'
#' @examples
#' \dontrun{
#' xp <- define_experiment("demo", "src/monty_hall_spatial_rev12.nlogox",
#'                         metrics = c("avg-hunch", "win-rate"),
#'                         constants = list("agent-density" = 50),
#'                         repetitions = 5, time_limit = 50)
#' run_experiment_to_duckdb(xp, "results/demo.duckdb")
#' }
run_experiment_to_duckdb <- function(experiment,
                                     db_path,
                                     table = "results",
                                     threads = 4L,
                                     timeout = Inf,
                                     metadata = NULL,
                                     smoke = FALSE,
                                     output = "table",
                                     tidy_output = TRUE,
                                     db_con = NULL,
                                     quiet_fail = FALSE,
                                     experiment_name = NULL,
                                     other_arguments = NULL,
                                     output_dir = tempdir()) {
  if (!inherits(experiment, "netlogo_experiment")) {
    stop("`experiment` must be a netlogo_experiment from define_experiment().",
         call. = FALSE)
  }
  if (is.null(db_con)) validate_path(db_path, "db_path", allow_memory = TRUE)
  validate_table(table)
  if (!is.null(threads) && !is_positive_integerish(threads)) {
    stop("`threads` must be NULL or one positive integer.", call. = FALSE)
  }
  if (!((is.numeric(timeout) && length(timeout) == 1L && !is.na(timeout) &&
         (is.infinite(timeout) && timeout > 0 || is.finite(timeout) && timeout >= 0)))) {
    stop("`timeout` must be one non-negative number or Inf.", call. = FALSE)
  }
  validate_metadata(metadata)
  if (!is_scalar_logical(smoke)) {
    stop("`smoke` must be one non-missing logical value.", call. = FALSE)
  }
  if (!is.character(output) || length(output) == 0L || anyNA(output) ||
      any(!nzchar(output))) {
    stop("`output` must be a non-empty character vector of output types.",
         call. = FALSE)
  }
  if (!is_scalar_logical(tidy_output)) {
    stop("`tidy_output` must be one non-missing logical value.", call. = FALSE)
  }
  if (!is_scalar_logical(quiet_fail)) {
    stop("`quiet_fail` must be one non-missing logical value.", call. = FALSE)
  }
  if (!is.null(experiment_name)) {
    validate_string(experiment_name, "experiment_name")
  }
  if (!is.null(other_arguments) &&
      (!is.character(other_arguments) || anyNA(other_arguments) ||
       any(!nzchar(other_arguments)))) {
    stop("`other_arguments` must be NULL or a character vector of ",
         "non-empty arguments.", call. = FALSE)
  }
  validate_string(output_dir, "output_dir")
  if (!dir.exists(output_dir)) {
    stop("`output_dir` does not exist: ", output_dir, call. = FALSE)
  }
  if (smoke && !is.null(experiment_name)) {
    stop("`smoke` cannot be combined with `experiment_name`: the model-file ",
         "experiment defines its own repetitions and time limit.", call. = FALSE)
  }
  if (!is.null(db_con)) validate_db_con(db_con)

  # Smoke mode: 1 rep x 5 ticks, without mutating the caller's object.
  if (smoke) {
    experiment <- define_experiment(
      name                = experiment$name,
      model               = experiment$model,
      metrics             = experiment$spec$metrics,
      constants           = experiment$spec$constants,
       sub_experiments     = experiment$spec$sub_experiments,
       repetitions         = 1L,
       time_limit          = 5L,
       run_metrics_every_step = FALSE,
       setup               = experiment$spec$setup,
       go                  = experiment$spec$go
     )
  }

  other_args <- if (is.null(threads)) {
    character()
  } else {
    paste("--threads", threads)
  }
  other_args <- c(other_args, other_arguments)
  if (length(other_args) == 0L) other_args <- NULL

  if (is.null(experiment_name)) {
    message("[", experiment$name, "] running ", experiment$spec$repetitions,
            " reps x ", experiment$spec$time_limit, " ticks ...")
  } else {
    message("[", experiment$name, "] running model-file experiment '",
            experiment_name, "' ...")
  }
  res <- tryCatch(
    logolink::run_experiment(
      model_path      = experiment$model,
      setup_file      = if (is.null(experiment_name)) experiment$setup_file,
      experiment      = experiment_name,
      output          = output,
      other_arguments = other_args,
      timeout         = timeout,
      tidy_output     = tidy_output,
      output_dir      = output_dir
    ),
    error = function(e) {
      message <- paste0("[", experiment$name, "] NetLogo experiment failed: ",
                        conditionMessage(e))
      if (quiet_fail) {
        warning(message, call. = FALSE)
        return(NULL)
      }
      stop(message, call. = FALSE)
    }
  )

  if (is.null(res) || is.null(res$table) || nrow(res$table) == 0L) {
    message("No rows produced; nothing appended.")
    return(invisible(0L))
  }

  tab <- as.data.frame(res$table)

  # Stamp run metadata as flat columns. A model-file experiment defines its own
  # repetitions and time limit, which the object's spec cannot describe.
  run_id  <- new_run_id(experiment$name)
  meta <- list(
    run_id      = run_id,
    experiment  = experiment$name,
    model_path  = experiment$model,
    timestamp   = as.character(Sys.time()),
    repetitions = if (is.null(experiment_name)) {
      experiment$spec$repetitions
    } else {
      NA_integer_
    },
    time_limit  = if (is.null(experiment_name)) {
      experiment$spec$time_limit
    } else {
      NA_integer_
    },
    threads     = if (is.null(threads)) NA_integer_ else threads
  )
  if (!is.null(experiment_name)) meta$experiment_name <- experiment_name
  if (!is.null(metadata)) meta <- c(meta, metadata)
  tab <- bind_metadata(tab, meta)

  con <- db_con
  close_after <- FALSE
  if (is.null(con)) {
    con <- db_open(db_path)
    close_after <- TRUE
  }

  n <- tryCatch(
    append_to_duckdb(con, tab, table),
    finally = if (close_after) db_close(con) else NULL
  )

  message("[", experiment$name, "] appended ", n, " rows -> ", table)
  invisible(n)
}

#' Run a simulation from a single function call
#'
#' Convenience wrapper that defines and runs an experiment in one step.
#'
#' @param name Experiment name.
#' @param model Path to the NetLogo model file.
#' @param db_path Path to the `.duckdb` database file.
#' @inheritParams define_experiment
#' @inheritParams run_experiment_to_duckdb
#'
#' @return Invisibly, the number of rows appended.
#' @export
#'
#' @examples
#' \dontrun{
#' run_simulation(
#'   name = "demo",
#'   model = "model.nlogox",
#'   db_path = "results.duckdb",
#'   metrics = "ticks",
#'   repetitions = 1,
#'   time_limit = 5
#' )
#' }
run_simulation <- function(name,
                           model,
                           db_path,
                           metrics = c("ticks", "avg-hunch", "win-rate"),
                           constants = list(),
                           sub_experiments = NULL,
                           repetitions = 100L,
                           time_limit = 500L,
                           run_metrics_every_step = FALSE,
                           setup = "setup",
                           go = "go",
                           table = "results",
                           threads = 4L,
                           timeout = Inf,
                           metadata = NULL,
                           smoke = FALSE,
                           output = "table",
                           tidy_output = TRUE,
                           db_con = NULL,
                           quiet_fail = FALSE,
                           experiment_name = NULL,
                           other_arguments = NULL,
                           output_dir = tempdir(),
                           ...) {
  xp <- define_experiment(
    name = name,
    model = model,
    metrics = metrics,
    constants = constants,
    sub_experiments = sub_experiments,
    repetitions = repetitions,
    time_limit = time_limit,
    run_metrics_every_step = run_metrics_every_step,
    setup = setup,
    go = go,
    ...
  )
  run_experiment_to_duckdb(
    experiment = xp,
    db_path = db_path,
    table = table,
    threads = threads,
    timeout = timeout,
    metadata = metadata,
    smoke = smoke,
    output = output,
    tidy_output = tidy_output,
    db_con = db_con,
    quiet_fail = quiet_fail,
    experiment_name = experiment_name,
    other_arguments = other_arguments,
    output_dir = output_dir
  )
}

# --- internal helpers -------------------------------------------------------

.run_state <- new.env(parent = emptyenv())
.run_state$counter <- 0L

# Generate an identifier that remains unique when runs start in the same
# second, including when multiple R processes write to the same database.
new_run_id <- function(experiment_name) {
  .run_state$counter <- .run_state$counter + 1L
  timestamp <- format(Sys.time(), "%Y%m%dT%H%M%OS6", tz = "UTC")
  token <- basename(tempfile(pattern = "netlogoDuck-run-"))
  paste(
    experiment_name,
    timestamp,
    Sys.getpid(),
    sprintf("%08d", .run_state$counter),
    token,
    sep = "-"
  )
}

bind_metadata <- function(tab, meta) {
  for (nm in names(meta)) {
    val <- meta[[nm]]
    if (is.atomic(val) && length(val) == 1L) {
      tab[[nm]] <- rep(val, nrow(tab))
    } else {
      tab[[nm]] <- I(rep(list(val), nrow(tab)))
    }
  }
  tab
}

append_to_duckdb <- function(con, tab, table) {
  if (!DBI::dbExistsTable(con, table)) {
    DBI::dbWriteTable(con, table, tab, temporary = FALSE)
    return(nrow(tab))
  }

  existing <- DBI::dbListFields(con, table)
  tab_cols <- names(tab)

  # New columns in `tab` not yet in the table -> widen the table.
  new_cols <- setdiff(tab_cols, existing)
  for (nm in new_cols) {
    DBI::dbExecute(con, paste0('ALTER TABLE "', table, '" ADD COLUMN "', nm, '" ',
                               duckdb_type_of(tab[[nm]])))
  }

  # Columns in the table that `tab` lacks -> fill with NA before appending.
  missing_in_tab <- setdiff(existing, tab_cols)
  for (nm in missing_in_tab) {
    tab[[nm]] <- NA
  }

  # Keep column order consistent with the table.
  tab <- tab[intersect(c(existing, new_cols), names(tab))]
  DBI::dbAppendTable(con, table, tab)
  nrow(tab)
}

# Map an R column to a DuckDB type for ALTER TABLE.
duckdb_type_of <- function(x) {
  if (is.factor(x)) x <- as.character(x)
  type <- switch(
    typeof(x),
    integer = "INTEGER",
    double  = "DOUBLE",
    logical = "BOOLEAN",
    character = "VARCHAR",
    "VARCHAR"
  )
  type
}
